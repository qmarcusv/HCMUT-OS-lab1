// main function to call display function
#include "calc.h"
int main(){
  display("logic"); // display function is called
}
